#pragma once

/*

dir structure ?

-common 
  base64 
  box 
  comem 
  path 
  punk 
  uni
-obj 
  obj 
  impl 
  inproc 
  localserver 
  marshall 
  module
-ole 
  persist  
  stgm. 
  stream
-aut 
  aut 
  disp
  bstr
  variant 
  enum 
  sfarray
-win 
  clipboard 
  wnd
  ctrl
  dlg
-script

*/