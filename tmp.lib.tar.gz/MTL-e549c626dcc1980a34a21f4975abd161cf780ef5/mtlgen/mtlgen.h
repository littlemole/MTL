﻿
#pragma once

#include <MTL/sdk.h>
#include <windows.h>
#include "disp.h"
#include "dllmodule.h"
#include "manifest.h"
#include "packer.h"
#include "reg.h"
#include "selfreg.h"
#include "wix.h"
#include "init.h"